/***********************************************************************
Write a function `arrayConverter(array)` that will intake an
array as an argument and returns an object representing the count of each
value in the array. **Hint:** don't forget you can check if a key is present
in an object by using `obj[key] === undefined`.

Examples:

console.log(arrayConverter(["apple", "apple"])); // => {apple: 2}
console.log(arrayConverter(["mango", "pineapple"])); // => {mango: 1, pineapple: 1}
console.log(arrayConverter(["apple", "banana", "potato", "banana"])); // => {apple: 1, banana: 2, potato: 1}
***********************************************************************/

//const { keyBy } = require("cypress/types/lodash");

function arrayConverter(array) {
  let valueCount = {};
  array.forEach(function(element) {
    if(valueCount[element] === undefined) {
      valueCount[element] = 1;
    }
    else {
      valueCount[element] = valueCount[element] + 1;
    }
  });
  return valueCount;
}

/**************DO NOT MODIFY ANYTHING UNDER THIS  LINE*****************/
module.exports = arrayConverter;
